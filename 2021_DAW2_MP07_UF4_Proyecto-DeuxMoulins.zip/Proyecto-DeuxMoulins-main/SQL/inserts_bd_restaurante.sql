INSERT INTO `mesa` (`disponible_mesa`, `plazas_mesa`, `lugar_mesa`) VALUES
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '1', 'Barra'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sofás'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '4', 'Sala'),
( 1, '2', 'Sala'),
( 1, '2', 'Sala'),
( 1, '2', 'Sala'),
( 1, '2', 'Sala'),
( 1, '2', 'Sala'),
( 1, '2', 'Sala'),
( 1, '4', 'Terraza'),
( 1, '4', 'Terraza'),
( 1, '4', 'Terraza'),
( 1, '4', 'Terraza'),
( 1, '4', 'Terraza'),
( 1, '4', 'Terraza');


INSERT INTO `camarero` ( `nombre`, `password`) VALUES
('david', '1fa3356b1eb65f144a367ff8560cb406'),
('camarero1', '1fa3356b1eb65f144a367ff8560cb406'),
('camarero2', '1fa3356b1eb65f144a367ff8560cb406'),
('camarero3', '1fa3356b1eb65f144a367ff8560cb406');


INSERT INTO `mantenimiento` (`id_mantenimiento`, `nombre`, `password`) VALUES
(1, 'mantenimiento1', '1fa3356b1eb65f144a367ff8560cb406'),
(2, 'mantenimiento2', '1fa3356b1eb65f144a367ff8560cb406');