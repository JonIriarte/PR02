<?php 
    define ("BD" ,"bd_restaurante");
    define ("SERVIDOR" ,"localhost");
    define ("USER" ,"root");
    define ("PASSWORD" ,"");
?>