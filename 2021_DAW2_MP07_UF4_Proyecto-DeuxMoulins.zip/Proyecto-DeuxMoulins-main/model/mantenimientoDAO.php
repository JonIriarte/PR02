<?php
//DAO=Data Access Object
require_once 'mantenimiento.php';
class MantenimientoDao{
    private $pdo;

    public function __construct(){
        include 'connection.php';
        $this->pdo=$pdo;
    }

    public function login($user){
        $query = "SELECT * FROM mantenimiento WHERE `nombre`=? AND `password`=?";
        $sentencia=$this->pdo->prepare($query);
        $nombre=$user->getNombre();//falta el getNombre
        $password=$user->getPassword();//falta el getPasswd
        $sentencia->bindParam(1,$nombre);
        $sentencia->bindParam(2,$password);
        $sentencia->execute();
        $result=$sentencia->fetch(PDO::FETCH_ASSOC);
        $numRow=$sentencia->rowCount();
        echo $numRow;
        if(!empty($numRow) && $numRow==1){
            //Creamos la sesión
            $user->setIdMantenimiento($result['id_mantenimiento']);//coge el id del camarero
            session_start();
            $_SESSION['nombre']=$user;//coge el nombre del camarero para mostrarlo en la página una vez realizado el login.
            return true;
        } else {
            return false;
        }
    }
}